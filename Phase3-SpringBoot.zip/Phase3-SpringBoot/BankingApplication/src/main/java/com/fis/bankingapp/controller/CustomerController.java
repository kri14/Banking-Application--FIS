package com.fis.bankingapp.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;
import com.fis.bankingapp.service.CustomerService;

/*
  {
    "custName" : "Kriti",
    "mobile" : 9915164472,
    "email": "x@gmail.com",
    "aadharNo": 882719243657,
    "dob": "2002-05-2002",
    "age" : 21,
    "rAddress" : "Pune",
    "pAddress" : "Chd",
    "password" : "xyz" 

    }
    
 */

@RestController
@RequestMapping("/HomePage")
public class CustomerController {
	@Autowired
	CustomerService service;

	@PostMapping("/Register") // http://localhost:8080/HomePage/Register
	public String register(@RequestBody Customer customer) {
		return service.createUser(customer);
	}

	@GetMapping("/Log/{email}/{password}") // http://localhost:8080/HomePage/Login
	public String Log(@PathVariable("email") String email, @PathVariable("password") String password) {
		try {
			service.Login(email, password);
			return "redirect:/CustomerAccount";
		} catch (AccountNotFoundException | PasswordIncorrect e) {
			System.out.println("Exception Found " + e );
		}
		return "redirect:/Register";

	}
	
	@PutMapping("/UpdateCustomer") // http://localhost:8080/HomePage/UpdateCustomer
	public String customer(@RequestBody Customer customer) {
		return service.updateUser(customer);
	}

	
	@DeleteMapping("/DeleteAccount/{id}/{password}") // http://localhost:8080/HomePage/DeleteAccount
	public String Delete(@PathVariable("id") int id, @PathVariable("password") String password) {
		try{
			return service.deleteUser(id, password);		
		}catch(PasswordIncorrect p) {
			return "Incorrect Password";
		}
	}

}
