package com.fis.bankingapp.service;

import com.fis.bankingapp.model.Account;
import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.repo.AccountRepo;

//This is used to call AccountRepo.

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepo dao;

	@Override
	public String createAccount(Account account) {
		dao.save(account);
		return "Account created succesfully";
	}

	@Override
	public boolean validate(long accNo, String password) throws AccountNotFound, PasswordIncorrect {
		Optional<Account> acc = dao.findById(accNo);
		if (acc.isEmpty())
			throw new AccountNotFound("Account not Found");
		else if (!acc.get().getPassword().equals(password))
			throw new PasswordIncorrect("Password Incorrect");

		else
			return true;
	}

	@Override
	public Account deposit(long accNo, double amt) throws AccountNotFound {
		dao.deposit(accNo, amt);
		return(dao.findByAccNo(accNo));
	}

	@Override
	public Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound {
		Account acc = dao.findByAccNo(accNo);
		if(acc== null)
			throw new AccountNotFound("No Account !!!");
		if(acc.getBalance()<amt)
			throw new BalanceNotFound("Low Balance !!!");
		dao.withdraw(accNo, amt);
		return(dao.findByAccNo(accNo));
	}

	@Override
	public String updatePassword(long accNo, String newPassword, String rePassword) {
		if (newPassword.equals(rePassword)) {
			dao.updatePassword(accNo, newPassword);
			return "Changed Successfully";
		}

		else
			return "Does not match";

	}

}
