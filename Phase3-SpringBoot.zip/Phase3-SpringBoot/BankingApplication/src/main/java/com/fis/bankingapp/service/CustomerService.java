package com.fis.bankingapp.service;

import javax.security.auth.login.AccountNotFoundException;

import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;

public interface CustomerService {

	public abstract String createUser(Customer customer);

	public abstract boolean Login(String email, String password) throws AccountNotFoundException, PasswordIncorrect;
	
	public abstract String deleteUser(int id, String password)  throws PasswordIncorrect;

	public abstract String updateUser(Customer customer);
}
