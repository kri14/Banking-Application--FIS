package com.fis.bankingapp.service;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Account;

public interface AccountService {
	public abstract String createAccount(Account account);

	public abstract boolean validate(long accNo, String password) throws AccountNotFound, PasswordIncorrect;

	public abstract Account deposit(long accNo, double amt) throws AccountNotFound;

	public abstract Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound;

	public abstract String updatePassword(long accNo, String newPassword, String rePassword);

}
