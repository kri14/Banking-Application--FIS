package com.fis.bankingapp.repo;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankingapp.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {

	public abstract Optional<Customer> findByEmail(String email);
	
	@Modifying
	@Query("Delete Customer c where c.custId = ?1 and c.password = ?2")
	public abstract int deleteUser(int id, String password);

}
