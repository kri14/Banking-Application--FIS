package com.fis.bankingapp.service;

import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;
import com.fis.bankingapp.repo.CustomerRepo;

//This is used to call CustomerRepo.

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepo dao;

	@Override
	public String createUser(Customer customer) {
		dao.save(customer);
		return "Customer Saved Sucessfully";
	}

	@Override
	public boolean Login(String email, String password) throws AccountNotFound, PasswordIncorrect {
		Optional<Customer> cus= dao.findByEmail(email);
		if(cus.isEmpty())
			throw new AccountNotFound("Customer Account not Found");
		else if(!cus.get().getPassword().equals(password))
			throw new PasswordIncorrect("Password Incorrect");
			
		else 
			return true;
	}

	
	@Override
	public String deleteUser(int id, String password)  throws PasswordIncorrect {
		if(dao.deleteUser(id, password) ==0) {
			throw new PasswordIncorrect("Incorrect pass ");
		};
		return "Customer Deleted Successfully";
	}

	@Override
	public String updateUser(Customer customer) {
		dao.save(customer);
		return "Customer Updated Succesfully";
	}
	
	
}
