package com.fis.bankingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Account;
import com.fis.bankingapp.model.Transaction;
import com.fis.bankingapp.service.AccountService;
import com.fis.bankingapp.service.TransactionService;



//{
//	"accType" : current,
//	"branch" : Pune,
//	"balance" : 1000,
//	"password" : xyz
//	
//}


@RestController
@RequestMapping("/CustomerAccount")
public class AccountController {
	@Autowired
	AccountService service ; 
	
	@Autowired
	TransactionService tservice;
	
	@PostMapping("/CreateAccount") // http://localhost:8080/CustomerAccount/CreateAccount
	public String create(@RequestBody Account account) {
		return service.createAccount(account);
	}
	
	@GetMapping("/Valid/{accNo}/{password}") //http://localhost:8080/CustomerAccount/Valid
	public  int valid(@PathVariable("accNo") long accNo,  @PathVariable("password") String password ) {
		try {
			service.validate(accNo, password);
			return 1;
		} catch (AccountNotFound | PasswordIncorrect e) {
			System.out.println("Exception Found !" + e );
		}
		return 0;
	}
	
	
	
	@GetMapping("/Deposit/{accNo}/{amt}") //http://localhost:8080/CustomerAccount/Deposit
	public String deposit(@PathVariable ("accNo") long accNo, @PathVariable("amt") double amt) {
		try{
			Account acc =  service.deposit(accNo, amt);
			Transaction t= new Transaction();
			t.setAccNoFrom(0);
			t.setAccNoTo(accNo);
			t.setAmount(amt);
			t.setBalance(acc.getBalance());
			t.setTransType("deposit");
			
			tservice.addTransaction(t);
			
			return acc.toString() ;
			
		}catch(AccountNotFound a ) {
			return "Error! account not found ";
		}
	
		
		}
	
	
	
	@GetMapping("/Withdraw/{accNo}/{password}/{amt}") //http://localhost:8080/CustomerAccount/Withdraw
	public String withdraw(@PathVariable ("accNo") long accNo,  @PathVariable("password") String password , @PathVariable("amt") double amt) {
		if(valid(accNo, password)==1) {
			try{
				
				Account acc =  service.withdraw(accNo, amt);
				Transaction t= new Transaction();
				t.setAccNoTo(0);
				t.setAccNoFrom(accNo);
				t.setAmount(amt);
				t.setBalance(acc.getBalance());
				t.setTransType("withdraw");
				
				tservice.addTransaction(t);
				
				return acc.toString() ;
				
			}catch (AccountNotFound| BalanceNotFound a)
			{
				return "Exception " + a ;
			}
			
			
		}
		return "Account /Password Incorrect. Recheck!";
			
	}
	
	
	@GetMapping("/TransferotherBank/{accNoTo}/{accNoFrom}/{password}/{amt}") //http://localhost:8080/CustomerAccount/TransferotherBank
	public String transferotherBank(@PathVariable ("accNoTo") long accNoTo, @PathVariable ("accNoFrom") long accNoFrom,  @PathVariable("password") String password , @PathVariable("amt") double amt) {
		int result = valid(accNoFrom, password);
		if(result == 0)
			return "Failed, accNo or password does not match ";
		else {
			try{
				Account acc =  service.withdraw(accNoFrom, amt);
			
			Transaction t= new Transaction();
			t.setAccNoTo(accNoTo);
			t.setAccNoFrom(accNoFrom);
			t.setAmount(amt);
			t.setBalance(acc.getBalance());
			t.setTransType("transfer to diff bank");
			
			tservice.addTransaction(t);
			
			return acc.toString() ;
			}catch (AccountNotFound a)
			{
				return "Account not found ";
			}
			catch(BalanceNotFound b )
			{
				return "Not enough balance , enter a smaller amount ";
			}
			
			
			
		}
			
	}
	
	
	
	@GetMapping("/UpdatePassword/{accNo}/{password}/{newpass}/{repass}")  //http://localhost:8080/CustomerAccount/UpdatePassword
	public String updatePass(@PathVariable ("accNo") long accNo,  @PathVariable("password") String password , @PathVariable("newpass") String newpass, @PathVariable("repass") String repass) {
		int result = valid(accNo, password);
		if(result == 0)
			return "Failed, accNo or password does not match ";
		else 
			return service.updatePassword(accNo, newpass, repass);
			
	}
	
	
	
	@GetMapping("/AllTransaction")  //http://localhost:8080/CustomerAccount/AllTransaction
	public List<Transaction>  AllTransaction(){
		return tservice.getAllTransaction();
	}
	
	@GetMapping("/TransactionByAccNo/{accNo}/{password}")  //http://localhost:8080/CustomerAccount/TransactionByAccNo
	public List<Transaction>  TransactionByAccNo(@PathVariable("accNo") long accNo, @PathVariable("password") String password ){
		int result = valid(accNo, password);
		if(result == 0)
			return null;
		else 
			return tservice.getAllTransactionByAccNo(accNo);
	}
	
	@GetMapping("/TransactionByDate/{startdate}/{enddate}")  //http://localhost:8080/CustomerAccount/TransactionByDate
	public List<Transaction> TransactionByDate( @PathVariable("startdate") String startdate, @PathVariable("enddate") String enddate  ){
		for (Transaction tr:tservice.getAllTransactionByDate(startdate, enddate)) {
			System.out.println(tr);
		}
			
			return tservice.getAllTransactionByDate(startdate, enddate);
	}
	
}
