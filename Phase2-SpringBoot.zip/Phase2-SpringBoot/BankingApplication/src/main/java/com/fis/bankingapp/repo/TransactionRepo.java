package com.fis.bankingapp.repo;

import java.util.List;

import com.fis.bankingapp.model.Transaction;

public interface TransactionRepo {
	public abstract String addTransaction(Transaction transaction);

	public abstract List<Transaction> getAllTransaction();

	public abstract List<Transaction> getAllTransactionByAccNo(long accNo);

	public abstract List<Transaction> getAllTransactionByDate(String startDate, String endDate);
}
