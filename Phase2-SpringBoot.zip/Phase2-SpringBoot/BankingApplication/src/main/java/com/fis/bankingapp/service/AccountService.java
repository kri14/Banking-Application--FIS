package com.fis.bankingapp.service;

import com.fis.bankingapp.model.Account;

import java.util.List;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;

public interface AccountService {
	public abstract String createAccount(Account account);

	public abstract List<Account> validate(long accNo, String password);

	// public abstract Account showBalance(long accNo, String password) throws
	// AccountNotFound, PasswordIncorrect;
	public abstract Account deposit(long accNo, double amt) throws AccountNotFound;

	public abstract Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound;

	public abstract String updatePassword(long accNo, String newPassword, String rePassword);

}
