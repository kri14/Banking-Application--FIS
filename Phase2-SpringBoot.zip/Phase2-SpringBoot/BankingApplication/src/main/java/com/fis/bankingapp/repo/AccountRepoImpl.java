package com.fis.bankingapp.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.model.Account;

@Repository
public class AccountRepoImpl implements AccountRepo {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String createAccount(Account account) {
		entityManager.persist(account);
		return "Account Created Successfully ! ";
	}

	@Override
	public List<Account> validate(long accNo, String password) {
		TypedQuery<Account> query = entityManager
				.createQuery("select a from Account a where a.accNo = ?1 and a.password = ?2", Account.class);
		query.setParameter(1, accNo);
		query.setParameter(2, password);
		return query.getResultList();
	}

	@Override
	public Account deposit(long accNo, double amt) throws AccountNotFound {
		Account a = entityManager.find(Account.class, accNo);
		if (a == null)
			throw new AccountNotFound("Account not found !!!");

		a.setBalance(a.getBalance() + amt);
		return a;
	}

	@Override
	public Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound {
		Account a = entityManager.find(Account.class, accNo);
		if (a == null)
			throw new AccountNotFound("Account not found !!!");
		if (amt > a.getBalance())
			throw new BalanceNotFound("Not enough balance !!!");
		a.setBalance(a.getBalance() - amt);
		return a;
	}

	@Override
	public String updatePassword(long accNo, String newPass, String rePass) {
		Account a = entityManager.find(Account.class, accNo);
		if (a == null)
			throw new AccountNotFound("Account not found !!!");
		if (newPass.equals(rePass))
			a.setPassword(newPass);
		else
			return ("doesnot match");
		return "Updated Sucessfully";
	}
}
