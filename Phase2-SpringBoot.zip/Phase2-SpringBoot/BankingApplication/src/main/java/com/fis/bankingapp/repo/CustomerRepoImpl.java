package com.fis.bankingapp.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;

@Repository
public class CustomerRepoImpl implements CustomerRepo {
	@PersistenceContext
	EntityManager entityManager;
	
	
	//to create the user 
	@Override
	public String createUser(Customer customer) {
		entityManager.persist(customer);
		return "Registered Successfully ! ";
	}
	
	// to login the account 
	@Override
	public List<Customer> Login(String email, String password) {
		TypedQuery<Customer> query = entityManager
				.createQuery("select c from Customer c where c.email = ?1 and c.password = ?2", Customer.class);
		query.setParameter(1, email);
		query.setParameter(2, password);
		return query.getResultList();

	}
	
	//to delete the user 
	@Override
	public String deleteUser(int id, String password) throws PasswordIncorrect {
		Customer c = entityManager.find(Customer.class, id);
		if (!c.getPassword().equals( password))
			throw new PasswordIncorrect("You entered the wrong password");
		else
			entityManager.remove(c);

		return "Product Removed Successfully";
	}

	//to update the user
	@Override
	public String updateUser(Customer customer) {
		entityManager.merge(customer);
		return "Updated Sucessfully";
	}
}
