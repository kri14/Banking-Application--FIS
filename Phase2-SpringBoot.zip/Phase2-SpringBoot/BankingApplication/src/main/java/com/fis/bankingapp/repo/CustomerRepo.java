package com.fis.bankingapp.repo;

import java.util.List;

import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;

public interface CustomerRepo {

	public abstract String createUser(Customer customer);

	public abstract List<Customer> Login(String email, String password);
	
	public abstract String deleteUser(int id, String password)  throws PasswordIncorrect;

	public abstract String updateUser(Customer customer);

}
