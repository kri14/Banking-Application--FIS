package com.fis.bankingapp.service;

import com.fis.bankingapp.model.Account;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.repo.AccountRepo;

//This is used to call AccountRepo.

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepo dao;

	@Override
	public String createAccount(Account account) {
		return dao.createAccount(account);
	}

	@Override
	public List<Account> validate(long accNo, String password) {
		return dao.validate(accNo, password);
	}

	@Override
	public Account deposit(long accNo, double amt) throws AccountNotFound {
		return dao.deposit(accNo, amt);
	}

	@Override
	public Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound {
		return dao.withdraw(accNo, amt);
	}

	@Override
	public String updatePassword(long accNo, String newPassword, String rePassword) {
		return dao.updatePassword(accNo, newPassword, rePassword);
	}

}
