package com.fis.bankingapp.exceptions;

@SuppressWarnings("serial")
public class BalanceNotFound extends RuntimeException {
	
	public BalanceNotFound(String message) {
		super(message);
	}

}
