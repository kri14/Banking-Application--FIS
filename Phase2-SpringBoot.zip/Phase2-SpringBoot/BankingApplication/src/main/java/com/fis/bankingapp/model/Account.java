package com.fis.bankingapp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account_info")
public class Account {

	// this has all the variable required to create an account of person in bank;

	@Id
	@GeneratedValue
	private long accNo;
	private String accType;
	private String branch;
	private double balance;
	private String password;

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Account() {

	}

	public Account(long accNo, String accType, String branch, double balance, String password) {
		super();
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
		this.password = password;
	}

	// here i can edit what to print with to string method
	@Override
	public String toString() {
		return "Account : [accNo=" + accNo + ", accType=" + accType + ", branch=" + branch + ", balance=" + balance
				+ "]";
	}

}
