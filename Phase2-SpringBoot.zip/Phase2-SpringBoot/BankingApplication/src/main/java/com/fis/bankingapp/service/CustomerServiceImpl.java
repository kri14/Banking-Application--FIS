package com.fis.bankingapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;
import com.fis.bankingapp.repo.CustomerRepo;

//This is used to call CustomerRepo.

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepo dao;

	@Override
	public String createUser(Customer customer) {
		return dao.createUser(customer);
	}

	@Override
	public List<Customer> Login(String email, String password) {
		return dao.Login(email, password);
	}

	@Override
	public String deleteUser(int id, String password)  throws PasswordIncorrect {
		return dao.deleteUser(id, password);
	}

	@Override
	public String updateUser(Customer customer) {
		return dao.updateUser(customer);
	}
	
	
}
