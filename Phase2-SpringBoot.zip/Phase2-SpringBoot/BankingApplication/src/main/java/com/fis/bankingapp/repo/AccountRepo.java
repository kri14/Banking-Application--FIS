package com.fis.bankingapp.repo;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.model.Account;

import java.util.List;

public interface AccountRepo {
	// This is the interface of Account repository for same account transaction
	// work.

	public abstract String createAccount(Account account);

	public abstract List<Account> validate(long accNo, String password);

	public abstract Account deposit(long accNo, double amt) throws AccountNotFound;

	public abstract Account withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound;

	public abstract String updatePassword(long accNo, String newPassword, String rePassword);

	// public abstract void accountStatement(long accNo, String password);
}
