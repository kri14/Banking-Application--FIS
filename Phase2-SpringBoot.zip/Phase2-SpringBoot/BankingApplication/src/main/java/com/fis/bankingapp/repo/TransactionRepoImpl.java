package com.fis.bankingapp.repo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapp.model.Transaction;

@Repository
public class TransactionRepoImpl implements TransactionRepo {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addTransaction(Transaction transaction) {

		entityManager.persist(transaction);
		return "Transaction Added Successfully ! ";
	}

	@Override
	public List<Transaction> getAllTransaction() {
		TypedQuery<Transaction> query = entityManager.createQuery("select t from Transaction t", Transaction.class);
		return query.getResultList();
	}

	//All transaction to a particular accNo 
	@Override
	public List<Transaction> getAllTransactionByAccNo(long accNo) {
		TypedQuery<Transaction> query = entityManager.createQuery("select t from Transaction t where t.accNoFrom =?1",
				Transaction.class);
		query.setParameter(1, accNo);
		return query.getResultList();
	}

	
	//between dates transaction
	@Override
	public List<Transaction> getAllTransactionByDate(String startDate, String endDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate = LocalDate.parse(startDate, formatter);
		LocalDate toDate = LocalDate.parse(endDate, formatter);

		TypedQuery<Transaction> query = entityManager
				.createQuery("select t from Transaction t where t.dateOfTrans between ?2 and ?3", Transaction.class);
		query.setParameter(2, fromDate);
		query.setParameter(3, toDate);
		return query.getResultList();
	}

}
