package com.fis.bankingapp.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name = "customer_info")
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	@Column(length = 10)
	private long mobile;
	private String email;
	private long aadharNo;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
	private LocalDate dob;
	private short age;
	private String rAddress;
	private String pAddress;
	private String password;

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public short getAge() {
		return age;
	}

	public void setAge(short age) {
		this.age = age;
	}

	public String getrAddress() {
		return rAddress;
	}

	public void setrAddress(String rAddress) {
		this.rAddress = rAddress;
	}

	public String getpAddress() {
		return pAddress;
	}

	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", mobile=" + mobile + ", email=" + email + ", aadharNo=" + aadharNo
				+ ", dob=" + dob + ", age=" + age + ", rAddress=" + rAddress + ", pAddress=" + pAddress + "]";
	}

	public Customer(String custName, long mobile, String email, long aadharNo, LocalDate dob, short age,
			String rAddress, String pAddress, String password) {
		super();
		this.custName = custName;
		this.mobile = mobile;
		this.email = email;
		this.aadharNo = aadharNo;
		this.dob = dob;
		this.age = age;
		this.rAddress = rAddress;
		this.pAddress = pAddress;
		this.password = password;
	}

}
