package com.fis.bankingapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankingapp.model.Transaction;
import com.fis.bankingapp.repo.TransactionRepo;

// This is used to call TransactionRepo.

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepo dao;

	@Override
	public String addTransaction(Transaction transaction) {
		return dao.addTransaction(transaction);
	}

	@Override
	public List<Transaction> getAllTransaction() {
		return dao.getAllTransaction();
	}

	@Override
	public List<Transaction> getAllTransactionByAccNo(long accNo) {
		return dao.getAllTransactionByAccNo(accNo);
	}

	@Override
	public List<Transaction> getAllTransactionByDate(String startDate, String endDate) {
		return dao.getAllTransactionByDate(startDate, endDate);
	}

}
