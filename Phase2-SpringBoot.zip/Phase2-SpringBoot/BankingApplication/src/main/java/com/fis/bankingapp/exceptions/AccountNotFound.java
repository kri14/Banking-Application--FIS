package com.fis.bankingapp.exceptions;

@SuppressWarnings("serial")
public class AccountNotFound extends RuntimeException {
	
	// This exception shows up when account number does not match
	public AccountNotFound(String message) {
		super(message);
	}

}
