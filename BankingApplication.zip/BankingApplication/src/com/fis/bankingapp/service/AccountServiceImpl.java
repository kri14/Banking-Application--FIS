package com.fis.bankingapp.service;

import com.fis.bankingapp.beans.Account;
import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.repo.AccountRepo;
import com.fis.bankingapp.repo.AccountRepoImpl;

//This is used to call AccountRepo.

public class AccountServiceImpl implements AccountService {

	AccountRepo dao = new AccountRepoImpl();

	@Override
	public String createAccount(Account account) {
		return dao.createAccount(account);
	}

	@Override
	public Account validate(long accNo, String password) throws AccountNotFound, PasswordIncorrect {
		return dao.validate(accNo, password);
	}

	@Override
	public Account deposit(long accNo, double amt) throws AccountNotFound {
		return dao.deposit(accNo, amt);
	}

	@Override
	public Account withdraw(Account cus, double amt) {
		return dao.withdraw(cus, amt);
	}

	@Override
	public String updatePassword(long accNo, String password, String newPassword, String rePassword) {
		return dao.updatePassword(accNo, password, newPassword, rePassword);
	}

}
