package com.fis.bankingapp.service;

import com.fis.bankingapp.beans.Account;
import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;

public interface AccountService {
	public abstract String createAccount(Account account);

	public abstract Account validate(long accNo, String password) throws AccountNotFound, PasswordIncorrect;

	// public abstract Account showBalance(long accNo, String password) throws
	// AccountNotFound, PasswordIncorrect;
	public abstract Account deposit(long accNo, double amt) throws AccountNotFound;

	public abstract Account withdraw(Account cus, double amt);

	public abstract String updatePassword(long accNo, String password, String newPassword, String rePassword);

}
