package com.fis.bankingapp.service;

import com.fis.bankingapp.beans.Customer;
import com.fis.bankingapp.exceptions.CustomerNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.repo.CustomerRepo;
import com.fis.bankingapp.repo.CustomerRepoImpl;

//This is used to call CustomerRepo.

public class CustomerServiceImpl implements CustomerService {

	CustomerRepo dao = new CustomerRepoImpl();

	@Override
	public String createUser(Customer customer) {
		return dao.createUser(customer);
	}

	@Override
	public Customer Login(String email, String password) throws CustomerNotFound, PasswordIncorrect {
		return dao.Login(email, password);
	}

}
