package com.fis.bankingapp.service;

import java.util.Set;

import com.fis.bankingapp.beans.Transaction;
import com.fis.bankingapp.repo.TransactionRepo;
import com.fis.bankingapp.repo.TransactionRepoImpl;

// This is used to call TransactionRepo.

public class TransactionServiceImpl implements TransactionService {
	TransactionRepo dao = new TransactionRepoImpl();

	@Override
	public String addTransaction(Transaction transaction) {
		return dao.addTransaction(transaction);
	}

	@Override
	public Set<Transaction> display(long accNo) {
		return dao.display(accNo);
	}

}
