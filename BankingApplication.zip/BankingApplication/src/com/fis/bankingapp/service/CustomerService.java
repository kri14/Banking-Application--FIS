package com.fis.bankingapp.service;

import com.fis.bankingapp.beans.Customer;
import com.fis.bankingapp.exceptions.CustomerNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;

public interface CustomerService {

	public abstract String createUser(Customer customer);

	public abstract Customer Login(String email, String password) throws CustomerNotFound, PasswordIncorrect;

}
