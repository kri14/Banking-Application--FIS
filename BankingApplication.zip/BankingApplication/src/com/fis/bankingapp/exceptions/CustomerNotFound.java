package com.fis.bankingapp.exceptions;

@SuppressWarnings("serial")
public class CustomerNotFound extends RuntimeException {
	// this warning shows up when customer email doesnot match 
	public CustomerNotFound(String message) {
		super(message);
	}

}
