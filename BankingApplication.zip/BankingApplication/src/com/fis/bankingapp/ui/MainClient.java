package com.fis.bankingapp.ui;

import java.util.Scanner;

import com.fis.bankingapp.beans.Customer;
import com.fis.bankingapp.exceptions.CustomerNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.service.CustomerService;
import com.fis.bankingapp.service.CustomerServiceImpl;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
// This contains the main function . It interacts with the customer class .

public class MainClient {

	public static void main(String[] args) {

		String custName;
		long mobile;
		String email;
		long aadharNo;
		String dateStr;
		LocalDate dob;
		short age;
		String rAddress;
		String pAddress;
		String password;

		Customer cus = null;
		CustomerService service = new CustomerServiceImpl();
		Scanner scanner = new Scanner(System.in);

		while (true) {

			System.out.println("*************************************************************");
			System.out.println("**************Banking Application ~ FIS GLOBAL***************");
			System.out.println("*************************************************************");

			System.out.println("\nChoose your option : ");
			System.out.println("1. Register");
			System.out.println("2. Login");
			System.out.println("3. Exit");
			String option = scanner.next();
			switch (option) {

			case "1":
				// Register

				System.out.println("\nAdd you details as instructed below :\n ");

				System.out.println("Enter your Name : ");
				scanner.nextLine();
				custName = scanner.nextLine();

				// checks for 10 digit mobile.
				System.out.println("Enter the 10 digit mobile : ");
				while (true) {
					mobile = scanner.nextLong();
					if (Long.toString(mobile).length() != 10) {
						System.out.println("Error! 10 digits only. Re-enter :  ");
						continue;
					} else
						break;
				}

				// checks for a valid gmail
				System.out.println("Enter email address");
				while (true) {
					email = scanner.next();
					if (email.endsWith("@gmail.com"))
						break;
					else
						System.out.println("re-enter @gmail.com : ");
				}

				System.out.println("Enter Aadhar No.");
				while (true) {
					aadharNo = scanner.nextLong();
					if (Long.toString(aadharNo).length() != 12) {
						System.out.println("Error! 12 Digit Aadhar Please. ");
						continue;
					} else
						break;
				}

				// used the date time parse exception.
				System.out.println("Enter dob dd/MM/yyyy :");
				while (true) {
					dateStr = scanner.next();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					try {
						dob = LocalDate.parse(dateStr, formatter);
						break;
					} catch (DateTimeParseException d) {
						System.out.println("you have entered the wrong date format. Re-enter:");
						continue;
					}
				}

				// To calculate the age of person in years, convert local date to period and
				// then get the years.
				LocalDate date1 = LocalDate.now();
				Period p = Period.between(dob, date1);
				age = (short) p.getYears();
				System.out.println(" Age : " + age);

				// here we input address also check if current address is same as permanent or
				// not.

				System.out.println("Enter rAddress :");
				rAddress = scanner.next();
				System.out.println("Is current address same as the permanent address? y/n ");

				char choice = scanner.next().charAt(0);
				if (choice == 'y')
					pAddress = rAddress;
				else {
					System.out.println("Enter your Permanent Address : ");
					pAddress = scanner.next();
				}

				while (true) {
					System.out.println("Enter password : ");
					password = scanner.next();
					System.out.println("Re-enter password : ");
					String rePassword = scanner.next();
					if (password.equals(rePassword))
						break;
					else {
						System.out.println("Password does not match. Re-enter : ");
						continue;
					}

				}

				cus = new Customer(custName, mobile, email, aadharNo, dob, age, rAddress, pAddress, password);
				System.out.println(service.createUser(cus));

				break;

			case "2":
				// Login

				System.out.println("Enter your Email/UserId. : ");
				email = scanner.next();
				System.out.println("Enter your Password : ");
				password = scanner.next();
				try {
					service.Login(email, password);
					System.out.println("Login Successful");
					BankServices.bankservices();
				} catch (CustomerNotFound c) {
					System.out.println("Invalid email");
				} catch (PasswordIncorrect e) {
					System.out.println("Invalid Password");
				}
				break;

			case "3":
				System.out.println("Thank You !!!!");
				scanner.close();
				System.exit(0);
				break;

			default:

				System.out.println("default ......");
				break;

			}

		}
	}
}