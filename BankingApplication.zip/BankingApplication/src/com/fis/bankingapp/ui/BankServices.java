package com.fis.bankingapp.ui;

import java.util.Scanner;
import java.util.Set;

import com.fis.bankingapp.beans.Account;
import com.fis.bankingapp.beans.Transaction;
import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.service.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

// this is called when the login to account is successful 
// Logic ->  one customer can have multiple account, but only one customer per bank

public class BankServices {

	public static void bankservices() {
		long accNo = 1000000000;
		String accType = "none";
		String branch = "Pune";
		double balance = 0;
		String password;

		// variables from transaction class

		int transId = 1;
		long accNoTo;
		double amount;
		LocalDate dateOfTrans;

		Account account = null;
		Transaction transaction = null;
		AccountService service = new AccountServiceImpl();
		TransactionService trService = new TransactionServiceImpl();

		Scanner scanner = new Scanner(System.in);

		while (true) {

			System.out.println("\n--------------- SELECT SERVICES -----------------\n");

			System.out.println("Choose your option : ");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Update Password");
			System.out.println("8. Exit ");
			String option = scanner.next();
			switch (option) {

			case "1":
				// this function takes input and then create the account using add function.

				while (true) {
					System.out.println("Add you details as instructed below : ");

					System.out.println("Enter accType : savings or current ?");
					accType = scanner.next();
					if (!accType.equalsIgnoreCase("savings") && !accType.equalsIgnoreCase("current")) {
						System.out.println("Enter savings or current as option");
						continue;
					}
					System.out.println("Enter password : ");
					password = scanner.next();
					++accNo;
					account = new Account(accNo, accType, branch, balance, password);
					System.out.println(service.createAccount(account) + " Your Account No is : " + accNo);

					break;

				}
				break;
			case "2":
				// this account shows the account balance to user, it calls the simple validate
				// function.

				System.out.println("Enter your AccountNo. : ");
				accNo = scanner.nextLong();
				System.out.println("Enter your Password : ");
				password = scanner.next();
				try {
					System.out.println(service.validate(accNo, password));
				} catch (AccountNotFound c) {
					System.out.println("Invalid AccNo.");
				} catch (PasswordIncorrect e) {
					System.out.println("Invalid Password");
				}
				break;

			case "3":
				// This is to deposit amount in account . It also calls the deposit & add
				// transaction function.
				System.out.println("Enter your AccountNo. : ");
				accNo = scanner.nextLong();
				System.out.println("Enter your Amount to be added : ");
				amount = scanner.nextDouble();
				try {
					Account cus = service.deposit(accNo, amount);
					System.out.println("Balance Added Successfully \n" + cus);
					++transId;
					transaction = new Transaction(transId, accNo, accNo, amount, LocalDate.now(), "deposit",
							cus.getBalance());
					trService.addTransaction(transaction);
				} catch (AccountNotFound c) {
					System.out.println("Invalid AccNo.");
				}

				break;

			case "4":
				// This is to withdraw amount in account . It also calls the withdraw & add
				// transaction function.
				// Here if u try to withdraw amount more than current balance an exception e is
				// thrown.

				System.out.println("Enter your AccountNo. : ");
				accNo = scanner.nextLong();
				System.out.println("Enter your Password : ");
				password = scanner.next();
				try {
					Account cus = service.validate(accNo, password);
					while (true) {
						try {
							System.out.println("Enter the amount ");
							amount = scanner.nextDouble();
							cus = service.withdraw(cus, amount);
							++transId;
							transaction = new Transaction(transId, accNo, accNo, amount, LocalDate.now(), "withdraw",
									cus.getBalance());
							trService.addTransaction(transaction);
							System.out.println(cus);
							break;
						} catch (Exception e) {
							System.out.println(
									"The amount entered exceeds your balance. Current Bal = " + cus.getBalance());
							continue;
						}
					}

				} catch (AccountNotFound cnf) {
					System.out.println("Invalid AccNo.");
				} catch (PasswordIncorrect pi) {
					System.out.println("Invalid Password");
				}

				break;
			case "5":
				// Transfers funds using three dummy methods. calls the validateUser, withdraw
				// deposit & add transaction function.

				System.out.println("Choose your fund transfer method :");
				System.out.println("1. NEFT ");
				System.out.println("2. RTGS ");
				System.out.println("3. IMPS ");

				int option1 = scanner.nextInt();
				switch (option1) {
				case 1:
					break;
				case 2:
					break;
				case 3:
					break;
				default:
					break;

				}

				System.out.println("Enter your AccountNo. : ");
				accNo = scanner.nextLong();
				System.out.println("Enter your Password : ");
				password = scanner.next();
				try {
					Account cus = service.validate(accNo, password);
					while (true) {
						try {
							System.out.println("Enter Beneficiaries AccountNo. : ");
							accNoTo = scanner.nextLong();
							System.out.println("Enter the amount :");
							amount = scanner.nextDouble();
							cus = service.withdraw(cus, amount);
							dateOfTrans = LocalDate.now();
							try {
								Account cusTo = service.deposit(accNoTo, amount);
								System.out.println("Amount Transfered Successfully \n" + cusTo);
								System.out.println(cus);
								++transId;
								transaction = new Transaction(transId, accNo, accNoTo, amount, dateOfTrans, "withdraw",
										cus.getBalance());
								trService.addTransaction(transaction);
								++transId;
								transaction = new Transaction(transId, accNoTo, accNo, amount, dateOfTrans, "deposit",
										cusTo.getBalance());
								trService.addTransaction(transaction);

							} catch (AccountNotFound cnf) {
								System.out.println("Unsuccessful Transaction\n" + service.deposit(accNo, amount));
								++transId;
								transaction = new Transaction(transId, accNo, accNo, amount, dateOfTrans, "null",
										cus.getBalance());
								trService.addTransaction(transaction);
							}
							break;
						} catch (Exception e) {
							System.out.println(
									"The amount entered exceeds your balance. Current Bal = " + cus.getBalance());
							continue;
						}
					}

				} catch (AccountNotFound cnf) {
					System.out.println("Invalid AccNo.");
				} catch (PasswordIncorrect pi) {
					System.out.println("Invalid Password");
				}

				break;
			case "6":

				// show the account summary here .

				System.out.println("How do you want to print the statement ? ");
				System.out.println("1. Complete Account Summary ");
				System.out.println("2. Account Statement In Between Time Period");

				int option2 = scanner.nextInt();
				switch (option2) {
				case 1:
					// this is for the full account summary

					System.out.println("\n------------------------------ACCOUNT SUMMARY--------------------------\n ");
					System.out.println("Enter your AccountNo. : ");
					accNo = scanner.nextLong();
					System.out.println("Enter your Password : ");
					password = scanner.next();
					try {

						System.out.println(service.validate(accNo, password));
						Set<Transaction> trs = trService.display(accNo);
						System.out.println("dateOfTrans \t accNoFrom \t accNoTo \t amount \t transType \t balance");
						for (Transaction tr : trs) {
							System.out.println(tr);
						}

					} catch (AccountNotFound c) {
						System.out.println("Invalid AccNo.");
					} catch (PasswordIncorrect e) {
						System.out.println("Invalid Password");
					}

					break;
				case 2:
					// this is for the to from summary . here i have kept the internal function same
					// as
					// upper case , just updated while loop

					System.out.println("Enter your AccountNo. : ");
					accNo = scanner.nextLong();
					System.out.println("Enter your Password : ");
					password = scanner.next();
					try {
						// input the date using localDate and parse method

						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

						service.validate(accNo, password);
						System.out.println("Enter the from date dd/MM/yyyy : ");
						String fromDateStr = scanner.next();
						LocalDate fromDate = LocalDate.parse(fromDateStr, formatter);
						System.out.println("Enter the to date dd/MM/yyyy: ");
						String toDateStr = scanner.next();
						LocalDate toDate = LocalDate.parse(toDateStr, formatter);

						// we call display function for transaction

						Set<Transaction> trs = trService.display(accNo);
						System.out.println(
								"\n------------------------------ACCOUNT SUMMARY--------------------------\n ");
						System.out.println("dateOfTrans \t accNoFrom \t accNoTo \t amount \t transType \t balance");
						for (Transaction tr : trs) {
							// before and after are used with dates to check compare dates
							if (tr.getDateOfTrans().isBefore(toDate) && tr.getDateOfTrans().isAfter(fromDate))
								System.out.println(tr);
						}

					} catch (AccountNotFound c) {
						System.out.println("Invalid AccNo.");
					} catch (PasswordIncorrect e) {
						System.out.println("Invalid Password");
					} catch (DateTimeParseException d) {
						System.out.println("Invalid Date");
					}

					break;
				default:
					System.out.println("Incorrect Option Entered !");
					break;

				}

				break;
			case "7":

				System.out.println("Enter your AccountNo. : ");
				accNo = scanner.nextLong();
				System.out.println("Enter your Password : ");
				password = scanner.next();

				try {

					System.out.println(service.validate(accNo, password));
					System.out.println("Enter the new password :");
					String newPassword = scanner.next();
					System.out.println("Re-Enter new password :");
					String rePassword = scanner.next();
					System.out.println(service.updatePassword(accNo, password, newPassword, rePassword));
				} catch (AccountNotFound cnf) {

					System.out.println("Enter valid account number....");

				} catch (PasswordIncorrect p) {
					System.out.println("Invalid password ... ");
				}

				break;

			case "8":
				System.out.println("Thank You !!!!");
				scanner.close();
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Options ... ");

			}
		}
	}

}
