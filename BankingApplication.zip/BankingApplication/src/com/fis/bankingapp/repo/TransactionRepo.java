package com.fis.bankingapp.repo;

import java.util.Set;

import com.fis.bankingapp.beans.Transaction;

public interface TransactionRepo {
	public abstract String addTransaction(Transaction transaction);

	public abstract Set<Transaction> display(long accNo);

}
