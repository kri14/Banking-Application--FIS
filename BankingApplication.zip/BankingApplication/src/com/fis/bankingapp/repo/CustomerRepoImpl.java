package com.fis.bankingapp.repo;

import java.util.HashMap;
import com.fis.bankingapp.beans.Customer;
import com.fis.bankingapp.exceptions.CustomerNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;

public class CustomerRepoImpl implements CustomerRepo {

	HashMap<String, Customer> customers = new HashMap<String, Customer>();

	@Override
	public String createUser(Customer customer) {
		customers.put(customer.getEmail(), customer);
		return "Registered Successfully ! ";
	}

	@Override
	public Customer Login(String email, String password) throws CustomerNotFound, PasswordIncorrect {

		// this method will check if email and password is correct or not
		if (customers.containsKey(email)) {
			Customer cus = customers.get(email);
			String pass = cus.getPassword();
			if (pass.equals(password))
				return customers.get(email);
			else {
				throw new PasswordIncorrect("Password Invalid !");
			}
		} else {
			throw new CustomerNotFound("Invalid EmailId ! ");
		}
	}
}
