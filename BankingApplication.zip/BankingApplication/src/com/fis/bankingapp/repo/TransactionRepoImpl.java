package com.fis.bankingapp.repo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import com.fis.bankingapp.beans.Transaction;

public class TransactionRepoImpl implements TransactionRepo {
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();

	@Override
	public String addTransaction(Transaction transaction) {
		// put method to add in transaction hash map.
		transactions.put(transaction.getTransId(), transaction);
		return "Transaction Added Successfully ! ";
	}

	public Set<Transaction> display(long accNo) {
		// here we are storing the key in form of set.
		Set<Integer> set = transactions.keySet();
		Iterator<Integer> keys = set.iterator();
		Set<Transaction> trs = new HashSet<Transaction>();
		while (keys.hasNext()) {
			int key = keys.next();
			Transaction tr = transactions.get(key);
			// we will output those transaction use from account matches user account
			if (tr.getAccNoFrom() == accNo)
				trs.add(tr);
		}
		return trs;
	}

}
