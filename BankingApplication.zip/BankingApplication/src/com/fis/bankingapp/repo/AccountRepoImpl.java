package com.fis.bankingapp.repo;

import java.util.HashMap;
import com.fis.bankingapp.beans.Account;
import com.fis.bankingapp.exceptions.*;

public class AccountRepoImpl implements AccountRepo {
	HashMap<Long, Account> accounts = new HashMap<Long, Account>();

	@Override
	public String createAccount(Account account) {
		// put method is used to add account number for a customer
		accounts.put(account.getAccNo(), account);
		return "Account Created Successfully ! ";
	}

	@Override
	public Account validate(long accNo, String password) throws AccountNotFound, PasswordIncorrect {
		// first check if account exists in the hash by checking the keys
		if (accounts.containsKey(accNo)) {
			// save the account who's count number matched
			Account cus = accounts.get(accNo);
			// now get the password for this said customer and verify it
			String pass = cus.getPassword();
			if (pass.equals(password))
				return accounts.get(accNo);
			else {
				throw new PasswordIncorrect("Password Invalid !");
			}
		} else {
			throw new AccountNotFound("Invalid Account !");
		}
	}

	@Override
	public Account deposit(long accNo, double amt) {
		if (accounts.containsKey(accNo)) {
			Account cus = accounts.get(accNo);
			// using set method set the new balance = old + amount
			double bal = amt + cus.getBalance();
			cus.setBalance(bal);
			System.out.println(" Balance Added Successfully !");
			return accounts.get(accNo);
		} else {
			throw new AccountNotFound("Invalid Account !");
		}
	}

	@Override
	public Account withdraw(Account cus, double amt) {
		// using set method set the new balance = old - amount
		double bal = (cus.getBalance() - amt);
		if (bal < 0)
			throw new IllegalArgumentException("balance is insufficient : ");
		else {
			cus.setBalance(bal);
			return cus;
		}
	}

	@Override
	public String updatePassword(long accNo, String password, String newPassword, String rePassword) {

		int n = 0;
		while (n != 3) {
			// here three tries are given to enter the correct password before the account
			// is locked .
			if (newPassword.equals(rePassword)) {

				Account cus = accounts.get(accNo);
				cus.setPassword(newPassword);

				// password changed
				return "Password changed successfully";

			} else {
				++n;
				// wrong confirmation.. password not changed
				System.out.println("Wrong confirmation password");
			}

		}

		return "3 attempts over !";

	}

}
