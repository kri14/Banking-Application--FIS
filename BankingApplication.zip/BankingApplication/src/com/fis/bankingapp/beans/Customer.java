package com.fis.bankingapp.beans;

import java.time.LocalDate;

public class Customer {

	private String custName;
	private long mobile;
	private String email;
	private long aadharNo;
	private LocalDate dob;
	private short age;
	private String rAddress;
	private String pAddress;
	private String password;

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public short getAge() {
		return age;
	}

	public void setAge(short age) {
		this.age = age;
	}

	public String getrAddress() {
		return rAddress;
	}

	public void setrAddress(String rAddress) {
		this.rAddress = rAddress;
	}

	public String getpAddress() {
		return pAddress;
	}

	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", mobile=" + mobile + ", email=" + email + ", aadharNo=" + aadharNo
				+ ", dob=" + dob + ", age=" + age + ", rAddress=" + rAddress + ", pAddress=" + pAddress + "]";
	}

	public Customer(String custName, long mobile, String email, long aadharNo, LocalDate dob, short age,
			String rAddress, String pAddress, String password) {
		super();
		this.custName = custName;
		this.mobile = mobile;
		this.email = email;
		this.aadharNo = aadharNo;
		this.dob = dob;
		this.age = age;
		this.rAddress = rAddress;
		this.pAddress = pAddress;
		this.password = password;
	}

}
